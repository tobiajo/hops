def speak():
    print("HELLO FROM BAZ!")
